export OUTDIR=~/out
export HOST=i686-w64-mingw32
export MAKEOPTS="-j4"                           # set to the number of cores you have on the machine
                                                        # divide by two if you have hyperthreading

